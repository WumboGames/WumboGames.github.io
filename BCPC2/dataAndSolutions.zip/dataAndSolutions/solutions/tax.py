#tax.py
n=input()
total=0
mod2Count=0
for i in map(int, input().split()):
	total+=4*i//3
	mod2Count+=1 if i%3==2 else 0
total+=(mod2Count+1)//2
print(total)