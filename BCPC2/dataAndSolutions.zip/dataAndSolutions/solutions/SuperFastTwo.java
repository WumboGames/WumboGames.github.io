import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;


//Operates on the [seemingly correct] assumption that every antiprime is some previous antiprime times a prime number
//while this gives the correct answer and is incredably quick, I can't prove whether it is correct.
//This can be generalied to be slightly more slow but still definitely fast enough for the given bounds if you want
//a solution that you can prove the correctness of.
public class SuperAntiPrimes {
	
	static int[] primes=new int[20];

	public static void main(String[] args) {
		int nPrimes=0;
		int candidate=2;
		while (nPrimes<primes.length)
			if (isPrime(candidate++))
				primes[nPrimes++]=candidate-1;
		ArrayList<Number> HCs=new ArrayList<>();
		//add 1
		TreeSet<Long> HCNs=new TreeSet<>();
		HCNs.add(1l);
		HCs.add(new Number());
		long oldBest=1;
		for (int i=0; i<130; i++) {
			ArrayList<Number> candidates=new ArrayList<>();
			for (Number oldHC:HCs) {
				for (int p=0; p<primes.length; p++) {
					Number next=new Number(oldHC, p);
					if (next.nFacts()<=oldBest)
						continue;
					candidates.add(next);
				}
			}
			Number min=candidates.get(0);
			long val=min.val();
			for (Number n:candidates) {
				if (n.val()<val) {
					val=n.val();
					min=n;
				}
			}
			if (val>1e16)
				break;
			HCs.add(min);
			System.out.println(val);
			oldBest=min.nFacts();
			HCNs.add(val);
		}
		Scanner s=new Scanner(System.in);
		int T=s.nextInt();
		for (int t=0; t<T; t++) {
			long q=s.nextLong();
			System.out.println(HCNs.ceiling(q));
		}
	}
	
	static boolean isPrime(int n) {
		for (int i=2; i*i<=n; i++)
			if (n%i==0)
				return false;
		return true;
	}
	
	static class Number {
		int[] nFacts=new int[20];
		
		//constructs the number 1
		public Number() {
		}
		
		//constructs other*primes[primeIndex]
		public Number(Number other, int primeIndex) {
			for (int i=0; i<primes.length; i++)
				nFacts[i]=other.nFacts[i];
			nFacts[primeIndex]++;
		}
		
		public long val() {
			long total=1;
			for (int p=0; p<primes.length; p++)
				for (int i=0; i<nFacts[p]; i++)
					total*=primes[p];
			return total;
		}
		
		public long nFacts() {
			long total=1;
			for (int p=0; p<primes.length; p++)
				total*=(1+nFacts[p]);
			return total;
		}
	}

}
