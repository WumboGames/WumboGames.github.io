#two.py
numFacts=[0]*11000000
for i in range(2, 11000000):
	for j in range(i, 11000000, i):
		numFacts[j]+=1;
#print("precomp done...")
#Hard-code those^ for the cheesy solution. The more complex solution can be programmed instead to calculate all
#antiprimes within the time limit in python

antiprimes=[]
best=-1
for i in range(1, 11000000):
	if numFacts[i] > best:
		best=numFacts[i]
		antiprimes.append(i)

n=int(input())
for i in range(0, n):
	min=int(input())
	for j in antiprimes:
		if (j>=min):
			print(j)
			break;