#goat.py
nObsticles=int(raw_input())
deltas=[0]*1000001
for i in raw_input().split():
	deltas[int(i)]+=1;

cs=[0]*1000001
cs[0]=deltas[0]
for i in range(1, 1000001):
	cs[i]=cs[i-1]+deltas[i]

total=0
nQueries=int(raw_input())
for i in range(0, nQueries):
	query=map(int, raw_input().split())
	total+=cs[query[1]]-cs[query[0]]
print(total)
	