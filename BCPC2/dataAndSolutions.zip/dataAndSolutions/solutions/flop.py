#flop.py
line = raw_input()
while (line != "everybody do the flop"):
	print ("wait for it...")
	line = raw_input()
print("FLOP!")