#funny.py
n=int(raw_input())
for i in raw_input().split():
	print(int(i)*int(i)/2 if int(i)%2==0 else "Can he do it? Cosecant!")