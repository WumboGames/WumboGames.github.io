#handle.py
n=int(input())
for i in range (0, n):
	line=input()
	total=1
	curCount=1
	for c in line:
		if c in "aeiou":
			curCount+=1
		else:
			total*=curCount
			curCount=1
	total*=curCount
	print(total)