import java.util.ArrayList;
import java.util.Scanner;

public class Snowflakes {
	public static void main(String[] args) {
		Scanner fs=new Scanner(System.in);
		int n=fs.nextInt(), nEdges=fs.nextInt();
		ArrayList<Integer>[] adj=new ArrayList[n];
		for (int i=0; i<n; i++) adj[i]=new ArrayList<>();
		for (int i=0; i<nEdges; i++) {
			int a=fs.nextInt()-1, b=fs.nextInt()-1;
			adj[a].add(b);
			adj[b].add(a);
		}
		
		int[] nSnowflakesOfDegree=new int[101];
		outer: for (int center=0; center<n; center++) {
			//the center of a snowflake needs to have degree != 1
			if (adj[center].size()==1) continue;
			
			for (int i:adj[center])
				if (adj[i].size()!=1)
					//center isn't a snowflake
					continue outer;
			
			//center is a snowflakes
			nSnowflakesOfDegree[adj[center].size()]++;
		}
		int special=0;
		for (int i: nSnowflakesOfDegree)
			if (i==1) special++;
		System.out.println(special);
	}
}
