import java.util.Scanner;

public class Three {

	public static void main(String[] args) {
		Scanner fs=new Scanner(System.in);
		int n=fs.nextInt();
		for (int i=0; i<n; i++) {
			System.out.println(i+" "+(i*i));
		}
	}

}
