import java.util.Scanner;

public class Balloons {

	public static void main(String[] args) {
		Scanner fs=new Scanner(System.in);
		int n=fs.nextInt();
		int low=fs.nextInt(), high=fs.nextInt();
		int time=fs.nextInt();
		int counter=0;
		
		for (int balloon=0; balloon<n; balloon++)  {
			// released at time 3, height at time 10 = 10-3 = 7
			int height=time-balloon;
			if (height>=low && height <=high) {
				counter++;
			}
		}
		System.out.println(counter);
	}

}
