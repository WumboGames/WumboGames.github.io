import java.util.ArrayList;
import java.util.Scanner;

public class Frenemies {

	public static void main(String[] args) {
		Scanner fs=new Scanner(System.in);
		int n=fs.nextInt(), m=fs.nextInt();
		int[] group=new int[n];
		ArrayList<Integer>[] inGroup=new ArrayList[n];
		for (int i=0; i<n; i++) inGroup[i]=new ArrayList<>();
		
		for (int i=0; i<n; i++) {
			group[i]=i;
			inGroup[i].add(i);
		}
		
		long frenemies=0;
		for (int talk=0; talk<m; talk++) {
			int a=fs.nextInt()-1, b=fs.nextInt()-1;
			if (group[a]==group[b]) {
				System.out.println(frenemies);
			}
			else {
				//complex work
				a=group[a]; b=group[b];
				frenemies+=inGroup[a].size()*(long)inGroup[b].size();
				
				//make a smaller of two
				if (inGroup[a].size()>inGroup[b].size()) {
					int temp=a;
					a=b;
					b=temp;
				}
				for (int i:inGroup[a]) {
					//each thing added only 20 times
					//this loop only runs 20*n times ever
					group[i]=b;
					inGroup[b].add(i);
				}
				inGroup[a].clear();
				
				System.out.println(frenemies);
			}
		}
	}

}
