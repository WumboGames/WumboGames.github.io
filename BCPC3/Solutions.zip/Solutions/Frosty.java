import java.util.Scanner;

public class Frosty {

	public static void main(String[] args) {
		Scanner fs=new Scanner(System.in);
		int n=fs.nextInt();
		int nElves=fs.nextInt();
		int D=-fs.nextInt();
		System.out.println(n + Math.max(0, n-D));
	}

}
