import java.util.Arrays;
import java.util.Scanner;

public class Linus {

	static int n;
	static char[] song;
	static int[][] dp;
	
	public static void main(String[] args) {
		//dynamic programming
		//dp[firstSong][second song] = how many notes
		Scanner fs=new Scanner(System.in);
		n=fs.nextInt();
		song=fs.next().toCharArray();

		dp=new int[n+1][n+1];
		for (int i=0; i<dp.length; i++) Arrays.fill(dp[i], -1);
		
		long totalLength=0;
		for (int i=0; i<n; i++)
			for (int j=0; j<n; j++)
				totalLength+=countLength(i, j);
		long gcd=gcd(totalLength, n*n);
		System.out.println(totalLength/gcd +"/"+(n*n/gcd));
	}
	
	static long gcd(long a, long b) {
		if (b==0) return a;
		return gcd(b, a%b);
	}
	
	//return number of beats we play for
	static int countLength(int a, int b) {
		if (dp[a][b]!=-1) return dp[a][b];
		if (Math.max(a, b)==n) return 0;
		if (song[a]!=song[b]) return 1;
		return dp[a][b]=1+countLength(a+1, b+1);
	}

}
