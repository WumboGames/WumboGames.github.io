import java.util.ArrayList;
import java.util.Scanner;

public class Windows {

	public static void main(String[] args) {
		//O(60)
		Scanner fs=new Scanner(System.in);
		int d=fs.nextInt();
		boolean[] illegal=new boolean[10];
		for (int i=0; i<d; i++)
			illegal[fs.nextInt()]=true;
		
		int[] nthLegal=new int[10];
		int counter=0;
		for (int i=0; i<10; i++)
			if (!illegal[i]) {
				nthLegal[counter++]=i;
			}
		
		int base=counter;
		long n=fs.nextLong();
		ArrayList<Integer> answer=new ArrayList<>();
		while (n!=0) {
			long digit=n%base;
			n/=base;
			answer.add(nthLegal[(int)digit]);
		}
		for (int i=answer.size()-1; i>=0; i--)
			System.out.print(answer.get(i));
		System.out.println();
	}

}
