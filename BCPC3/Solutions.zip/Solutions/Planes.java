import java.util.Arrays;
import java.util.Scanner;

public class Planes {

	public static void main(String[] args) {
		//need n*(n-1)/2, but we can add n
		Scanner fs=new Scanner(System.in);
		int n=fs.nextInt(), m=fs.nextInt();
		Edge[] edges=new Edge[m];
		for (int i=0; i<m; i++) edges[i]=new Edge(fs.nextInt(), fs.nextInt());
		Arrays.sort(edges);
		
		int unique=edges.length>0?1:0;
		for (int i=0; i+1<m; i++)
			if (edges[i].from!=edges[i+1].from ||
				edges[i].to!=edges[i+1].to)
				unique++;
		unique+=n;
		
		if (unique>=n*(long)(n-1)/2)
			//we can make everything 1 away
			System.out.println(1);
		else
			//we can't
			System.out.println(0);
				
	}
	
	static class Edge implements Comparable<Edge> {
		int from, to;
		public Edge(int from, int to) {
			this.from=Math.min(from, to);
			this.to=Math.max(from, to);
		}
		
		public int compareTo(Edge o) {
			if (from!=o.from) return Integer.compare(from, o.from);
			return Integer.compare(to, o.to);
		}
	}

}
