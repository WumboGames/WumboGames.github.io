
//
// File:    mismatch2.java
// Purpose: generates a java error mismatch filename/class.
// Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
// Oct 13 1998
//
// $Id$
//

public class MisMatch2 {
    public static void main(String[] args) 
    {
         System.out.println("Hello World.");
    }
}

// eof
