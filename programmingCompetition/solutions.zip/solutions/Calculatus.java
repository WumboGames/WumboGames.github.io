import java.awt.Point;
import java.util.ArrayList;
import java.util.Scanner;

/*
This is the original intended solution to the problem. It should be noted, however, that a
slightly more straight forward solution exists as is explained in the solution video.
*/
public class Calculatus {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int u=s.nextInt();
		//You can use the point class because it stores two integers, which we use as the start and end of a range
		ArrayList<Point> ranges=new ArrayList<>();
		for (int i=0; i<u; i++) {
			ranges.add(new Point(s.nextInt(), s.nextInt()));
		}

		boolean changeMade=false;
		do {//keep combining ranges until there are no more ways to do so.
			changeMade=false;
			for (int outerIndex=0; outerIndex<ranges.size(); outerIndex++) {
				for (int innerIndex=outerIndex+1; innerIndex<ranges.size(); innerIndex++) {
					if (rangesOverlap(ranges.get(outerIndex), ranges.get(innerIndex))) {
						Point b=ranges.remove(innerIndex);//inner index is bigger
						Point a=ranges.remove(outerIndex);
						ranges.add(new Point(Math.min(a.x, b.x), Math.max(a.y, b.y)));
						changeMade=true;
					}
				}
			}
		} while (changeMade);

		//once we have combined all possible ranges, there are only three possible cases:
		if (ranges.size()==2) {//case 1: the missing space is between the two ranges that are left
			System.out.println(1+Math.min(ranges.get(0).y, ranges.get(1).y));
		}
		else if (ranges.size()==1) {
			if (ranges.get(0).x==1) {//case 2: there is one range left, starting at 1 (the space at n is not included)
				System.out.println(n);
			}
			else {//case 3: there is one range left, but space 1 is never included
				System.out.println(1);
			}
		}
	}

	private static boolean rangesOverlap(Point rangeA, Point rangeB) {
		return !(rangeA.y+1<rangeB.x||rangeB.y+1<rangeA.x);
	}

}
