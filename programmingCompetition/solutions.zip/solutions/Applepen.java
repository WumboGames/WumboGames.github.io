import java.util.Scanner;

public class Applepen {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int testCases=s.nextInt();
		s.nextLine();//clear the new line character after n is inputted.
		for (int testCase=0; testCase<testCases; testCase++) {
			String line1=s.nextLine();
			String line2=s.nextLine();
			System.out.println("Uh! "+line2.split(" ")[3]+"-"+line1.split(" ")[3]+"!");
		}

	}

}
