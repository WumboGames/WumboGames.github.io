package videos;

import java.util.Scanner;

public class LAST {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int testCases=s.nextInt();
		for (int testCase=0; testCase<testCases; testCase++) {
			long rank=s.nextLong()-1;
			String asString=Long.toBinaryString(rank);
			int counter=0;
			for (int i=0; i<asString.length(); i++) {
				if (asString.charAt(i)=='1') {
					counter++;
				}
			}
			
			if (counter%2==0) {
				System.out.println("Red");
			}
			else {
				System.out.println("Blue");
			}
		}

	}

}
