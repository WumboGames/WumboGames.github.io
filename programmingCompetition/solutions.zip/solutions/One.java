import java.util.Scanner;

public class One {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int testCases=s.nextInt();
		outer: for (int testCase=0; testCase<testCases; testCase++) {
			int toCheck=s.nextInt();
			if (toCheck==1) {
				System.out.println("Neither");
				continue outer;
			}
			if (isPrime(toCheck)) {
				System.out.println("Prime");
			}
			else {
				System.out.println("Composite");
			}
		}

	}

	private static boolean isPrime(int toCheck) {
		//Simply counting up to toCheck is not efficient enough to get the correct
		//answer in time. We know that we only have to check up to the square root
		//of a number because if a*b==c, and a<=b, a is greatest in the case when
		//a==b, in which case a==b==sqrt(c); In all other cases, a<sqrt(b)<c.
		//for (int i=2; i<toCheck; i++) {
		for (int i=2; i<Math.min(toCheck, Math.sqrt(toCheck)+1); i++) {
			if (toCheck%i==0) {
				return false;
			}
		}
		return true;
	}

}
