package videos;

import java.util.Scanner;

//here is the solution to the problem, as explained in the solution video for
//Race.
public class Race {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int testCases=s.nextInt();
		for (int testCase=0; testCase<testCases; testCase++) {
			int numberOfIntersections=s.nextInt();
			int numberOfRoads=s.nextInt();
			int[][] distance=new int[numberOfIntersections][numberOfIntersections];
			for (int i=0; i<numberOfIntersections; i++) {
				for (int j=0; j<numberOfIntersections; j++) {
					distance[i][j]=100000;
				}
				distance[i][i]=0;
			}

			for (int i=0; i<numberOfRoads; i++) {
				int firstIntersection=s.nextInt();
				int secondIntersection=s.nextInt();
				distance[firstIntersection][secondIntersection]=1;
				distance[secondIntersection][firstIntersection]=1;
			}

			//This is called the Floyd-Warshall Algorythm.
			//A more detailed explanation than what is provided in the solution
			//video is available here: 
			//https://en.wikipedia.org/wiki/Floyd%E2%80%93Warshall_algorithm
			for (int i=0; i<numberOfIntersections; i++) {
				for (int j=0; j<numberOfIntersections; j++) {
					for (int k=0; k<numberOfIntersections; k++) {
						distance[i][j]=Math.min(distance[i][j], distance[i][k]+distance[k][j]);
					}
				}
			}

			int max=-1;
			for (int[] i:distance) {
				for (int j:i) {
					max=Math.max(max, j);
				}
			}

			System.out.println(max+1);

		}

	}

}
