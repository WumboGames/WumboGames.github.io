import java.util.Scanner;

public class Negligence {

	public static void main(String[] args) {

		Scanner s=new Scanner(System.in);
		int testCases=s.nextInt();

		for (int testCase=0; testCase<testCases; testCase++) {
			long requests=s.nextLong();
			int charactersInLanguage=s.nextInt();
			int length=1;
			long totalKeystrokes=0;
			while (requests>0) {
				//This math is explained in the solution video for Negligent Norbert
				//Counting the total number of keystrokes without acutally generating
				//each answer is possible by counting how many answers there will be
				//of a given length, and then calculating the number of characters that
				//would be used to make that number of answers. 
				totalKeystrokes+=length*Math.min(Math.pow(charactersInLanguage, length), requests);
				requests-=Math.min(Math.pow(charactersInLanguage, length), requests);
				length++;
			}
			System.out.println(totalKeystrokes);

		}
	}

}
