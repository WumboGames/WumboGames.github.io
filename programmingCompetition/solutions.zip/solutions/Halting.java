import java.util.Arrays;
import java.util.Scanner;

public class Halting {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int testCases=s.nextInt();
		outer: for (int testCase=0; testCase<testCases; testCase++) {
			int numberOfCars=s.nextInt();
			int timeToCross=s.nextInt();
			int[] arrivalTimes=new int[numberOfCars];
			for (int i=0; i<numberOfCars; i++) {
				arrivalTimes[i]=s.nextInt();
			}

			//this is a working approach because each car takes the same amount of
			//time to cross the intersection
			Arrays.sort(arrivalTimes);

			for (int i=0; i<numberOfCars-1; i++) {
				if (arrivalTimes[i+1]-arrivalTimes[i]<timeToCross) {
					System.out.println("YES");
					continue outer;
				}
			}
			System.out.println("NO");
		}
	}
}
