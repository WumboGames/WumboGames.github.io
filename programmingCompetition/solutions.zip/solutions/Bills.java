import java.util.Scanner;

public class Bills {

	public static void main(String[] args) {
		//print the first number given
		System.out.println(new Scanner(System.in).nextInt());
	}

}
